#!/system/bin/sh
# 文件重命名为: init-service.sh
# 功能: 模块启动时的初始化脚本

MODDIR=${0%/*}

# 安全初始化：禁用伪装
if [ -f "/sys/class/qcom-battery/fake_temp" ]; then
    chmod 0666 "/sys/class/qcom-battery/fake_temp" 2>/dev/null
    echo 0 > "/sys/class/qcom-battery/fake_temp" 2>/dev/null
    chmod 0444 "/sys/class/qcom-battery/fake_temp" 2>/dev/null
fi

# 重置模块描述
sed -i '/^description=/s/=.*$/=/' "$MODDIR/module.prop"
sed -i "/description=/s/$/[😇😇等待充电检测😇😇] /" "$MODDIR/module.prop"
