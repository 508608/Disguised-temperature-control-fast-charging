if [ ! -f "/sys/class/qcom-battery/fake_temp" ]; then
    abort "- 未检测到 <fake_temp> 节点❗"
else
    echo "- 模块刷入后可在管理器内操作是否伪装温度(默认25°)，无循环脚本后台运行"
    echo "- 可在48°后仍保持较高的充电速度"
    echo "- 建议做好散热处理再使用该模块"
    echo "- 重启以享用模块😇"
fi
